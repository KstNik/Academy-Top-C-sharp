﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using VersOne.Epub; /* !устанавливается с помощью NuGet Package Manager в Visual Studio, порядок действий
(c https://learn.microsoft.com/ru-ru/nuget/consume-packages/install-use-packages-visual-studio):
открыть этот проект в Visual Studio -> пункт меню «Проект» -> подпункт «Управление пакетами NuGet…» -> 
в открывшейся вкладке «NuGet: BookReader*» выбрать пункт меню «Обзор» -> в строке поиска заполнить 
VersOne.Epub -> в левом окне выбрать VersOne.Epub -> в правом окне нажать кнопку «Установить» -> 
в появившемся диалоговом окне «Просмотр изменений» нажать кнопку «OK»*/
using Microsoft.Office.Interop.Word; // !устанавливается аналогично using VersOne.Epub

namespace BookReader {
    public partial class MainForm : Form {
        private System.Windows.Forms.Button[] buttons; // создание массива кнопок для их блокировки / разблокировки
        private string[] pages;
        private int currentPage = 0;
        private int searchStartPosition = 0;
        private int bookmark = 0;
        private Dictionary<string, string> comments = new Dictionary<string, string>(); // словарь для хранения комментариев
        public MainForm() {
            InitializeComponent();
            buttons = new System.Windows.Forms.Button[] { prevButton, nextButton, goToButton, setButton, goButton, addFavoritesButton, searchButton, addCommentButton };
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink; // запрет изменения размера
            this.MaximizeBox = false; // запрет развёртывания на весь экран
            pageTextBox.ScrollBars = ScrollBars.Vertical; // вертикальная полоса прокрутки
            richTextBox.Visible= false; // скрытие richTextBox
            foreach (System.Windows.Forms.Button button in buttons) // блокировка кнопок если файл не открыт
                button.Enabled = false;
            themesComboBox.Items.Add("Light");
            themesComboBox.Items.Add("Dark");
            themesComboBox.SelectedIndex = 0; // светлая тема по умолчанию
        }
        private void openButton_Click(object sender, EventArgs e) {
            try {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "TEXT Files (*.txt)|*.txt|EPUB Files (*.epub)|*.epub|RTF Files (*.rtf)|*.rtf|DOCX Files (*.docx)|*.docx";
                if (openFileDialog.ShowDialog() == DialogResult.OK) {
                    string filename = openFileDialog.FileName;
                    string text = "";
                    int pageSize = 1800;
                    if (filename.EndsWith(".txt")) // чтение текста из файла TXT
                        text = File.ReadAllText(filename);
                    else if (filename.EndsWith(".epub")) { // чтение текста из файла EPUB, для работы кода необходимо установить библиотеку using VersOne.Epub
                        pageSize = 1850;
                        EpubBook epubBook = EpubReader.ReadBook(filename);
                        DialogResult result = MessageBox.Show("Удалить спецсимволы?", "Вопрос", MessageBoxButtons.YesNo, MessageBoxIcon.Question); // вывод модального диалогового окна с запросом
                        foreach (VersOne.Epub.EpubLocalTextContentFile textContentFile in epubBook.ReadingOrder) {
                            if (result == DialogResult.Yes) {
                                string cleanedText = System.Text.RegularExpressions.Regex.Replace(textContentFile.Content, @"<[^>]*>", ""); // удаление спецсимволов, т.е. текста заключённого между знаками < и > совместно с этими знаками
                                text += cleanedText;
                            }
                            else
                                 text += textContentFile.Content;
                        }
                    }
                    else if (filename.EndsWith(".rtf")) { // чтение текста из файла RTF
                        pageSize = 2000;
                        using (StreamReader streamReader = new StreamReader(filename)) {
                            string rtfContent = streamReader.ReadToEnd();
                            richTextBox.Rtf = rtfContent;
                        }
                        text = Regex.Replace(richTextBox.Text, "<.*?>", string.Empty);
                    }
                    else if (filename.EndsWith(".docx")) { // чтение текста из файла DOCX, для работы кода необходимо установить библиотеку using Microsoft.Office.Interop.Word
                        pageSize = 1950;
                        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();
                        Document doc = wordApp.Documents.Open(filename);
                        text = doc.Content.Text;
                        wordApp.Quit();
                    }
                    int pageCount = (int)Math.Ceiling((double)text.Length / pageSize);
                    pages = new string[pageCount];
                    int startIndex = 0;
                    for (int i = 0; i < pageCount; i++) {
                        int endIndex = Math.Min(startIndex + pageSize, text.Length);
                        if (endIndex < text.Length && !char.IsWhiteSpace(text[endIndex - 1])) {
                            endIndex = text.LastIndexOf(' ', endIndex - 1, pageSize) + 1;
                            if (endIndex == 0 || endIndex < startIndex)
                                endIndex = startIndex + pageSize;
                        }
                        pages[i] = text.Substring(startIndex, endIndex - startIndex);
                        startIndex = endIndex;
                    }
                    foreach (System.Windows.Forms.Button button in buttons) // разблокировка кнопок
                        button.Enabled = true;
                    currentPage = 0;
                    DisplayCurrentPage();
                }
            }
            catch (IOException ex) {
                MessageBox.Show("Error I/O: " + ex.Message);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void toOpenButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(openButton, "Открытие текстового файла");
        }
        private void viewLibraryButton_Click(object sender, EventArgs e) {
            try {
                string libraryPath = Path.Combine(System.Windows.Forms.Application.StartupPath, "Library");
                if (!Directory.Exists(libraryPath))
                    Directory.CreateDirectory(libraryPath);
                string[] supportedExtensions = new string[] { ".txt", ".epub", ".rtf", ".docx" };
                var files = Directory.EnumerateFiles(libraryPath, "*.*", SearchOption.TopDirectoryOnly)
                                     .Where(file => supportedExtensions.Contains(Path.GetExtension(file)))
                                     .Select(file => Path.GetFileName(file));
                MessageBox.Show("Files in Library folder:\n" + string.Join("\n", files));
            }
            catch (IOException ex) {
                MessageBox.Show("Error I/O: " + ex.Message);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void toViewLibraryButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(viewLibraryButton, "Отображение списка книг в библиотеке");
        }
        private void prevButton_Click(object sender, EventArgs e) {
            if (currentPage > 0) {
                currentPage--;
                DisplayCurrentPage();
            }
        }
        private void toPrevButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(prevButton, "Переход на предыдущую страницу");
        }
        private void nextButton_Click(object sender, EventArgs e) {
            if (currentPage < pages.Length - 1) {
                currentPage++;
                DisplayCurrentPage();
            }
        }
        private void toNextButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(nextButton, "Переход на следующую страницу");
        }
        private void goToButton_Click(object sender, EventArgs e) {
            int page;
            if (int.TryParse(goToTextBox.Text, out page) && page >= 1 && page <= pages.Length) {
                currentPage = page - 1;
                DisplayCurrentPage();
            }
            else 
                MessageBox.Show("Invalid page number");
        }
        private void toGoToButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(goToButton, "Переход на страницу c номером, указанным в поле под кнопкой");
        }
        private void setButton_Click(object sender, EventArgs e) {
            bookmark = currentPage;
        }
        private void toSetButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(setButton, "Установка закладки на отображаемой странице");
        }
        private void goButton_Click(object sender, EventArgs e) {
            currentPage = bookmark;
            DisplayCurrentPage();
        }
        private void toGoButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(goButton, "Переход к закладке");
        }
        private void addFavoritesButton_Click(object sender, EventArgs e) {
            try {
                string selectedText = pageTextBox.SelectedText;
                string favoritesFilePath = Path.Combine(System.Windows.Forms.Application.StartupPath, "Favorites.txt");
                if (!File.Exists(favoritesFilePath))
                    File.WriteAllText(favoritesFilePath, selectedText);
                else
                    File.AppendAllText(favoritesFilePath, Environment.NewLine + selectedText);
            }
            catch (IOException ex) {
                MessageBox.Show("Error I/O: " + ex.Message);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void toAddFavoritesButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(addFavoritesButton, "Добавление выделенного текста в txt-файл \"Избранное (Favorites)\"");
        }
        private void readFavoritesButton_Click(object sender, EventArgs e) {
            try {
                string favoritesFilePath = Path.Combine(System.Windows.Forms.Application.StartupPath, "Favorites.txt");
                if (!File.Exists(favoritesFilePath))
                    File.Create(favoritesFilePath).Close();
                System.Diagnostics.Process.Start("notepad.exe", favoritesFilePath);
            }
            catch (IOException ex) {
                MessageBox.Show("Error I/O: " + ex.Message);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void toReadFavoritesButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(readFavoritesButton, "Просмотр txt-файла \"Избранное (Favorites)\"");
        }
        private void themesComboBox_SelectedIndexChanged(object sender, EventArgs e) {
            string selectedTheme = themesComboBox.SelectedItem.ToString();
            if (selectedTheme == "Light") { // светлая тема
                this.BackColor = System.Drawing.Color.White;
                this.ForeColor = System.Drawing.Color.Black;
            }
            else if (selectedTheme == "Dark") { // тёмная тема
                this.BackColor = System.Drawing.Color.Black;
                this.ForeColor = System.Drawing.Color.Gray;
            }
        }
        private void toThemesComboBox_MouseHover(object sender, EventArgs e) { // подсказка к списку
            buttonToolTip.SetToolTip(themesComboBox, "Список тем оформления");
        }
        private void searchButton_Click(object sender, EventArgs e) {
            string searchText = searchTextBox.Text.ToLower();
            int pageIndex = currentPage;
            for (int i = pageIndex; i < pages.Length; i++) {
                int startPos = 0;
                if (i == pageIndex)
                    startPos = searchStartPosition;
                int index = pages[i].ToLower().IndexOf(searchText, startPos);
                if (index != -1) {
                    currentPage = i;
                    searchStartPosition = index + searchText.Length;
                    DisplayCurrentPage();
                    pageTextBox.Select(index, searchText.Length);
                    pageTextBox.Focus();
                    return;
                }
                searchStartPosition = 0;
            }
            MessageBox.Show("Text not found");
        }
        private void toSearchButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(searchButton, "Поиск слова или текста в книге, указанного в поле справа от кнопки");
        }
        private void addCommentButton_Click(object sender, EventArgs e) {
            if (!string.IsNullOrWhiteSpace(pageTextBox.SelectedText) && !string.IsNullOrWhiteSpace(commentTextBox.Text)) {
                string selectedText = pageTextBox.SelectedText;
                string comment = commentTextBox.Text;
                if (!comments.ContainsKey(selectedText))
                    comments.Add(selectedText, comment);
                else
                    comments[selectedText] = comment; // обновление существующего комментария
            }
        }
        private void toAddCommentButton_MouseHover(object sender, EventArgs e) { // подсказка к кнопке
            buttonToolTip.SetToolTip(addCommentButton, "Добавление комментария – заполнить поле под кнопкой (комментарий), \nвыделить слово или текст в книге и нажать кнопку");
        }
        private void pageTextBox_SelectionChanged(object sender, EventArgs e) { // привязана к событию Click pageTextBox
            if (!string.IsNullOrWhiteSpace(pageTextBox.SelectedText)) {
                string selectedText = pageTextBox.SelectedText;
                if (comments.ContainsKey(selectedText))
                    commentLabel.Text = "Comment: " + comments[selectedText]; // отображение комментария при выделении текста
                else
                    commentLabel.Text = "Comment:"; // сброс комментария при выделении другого текста
            }
        }
        private void toCommentLabel_MouseHover(object sender, EventArgs e) { // подсказка к текстовому полю
            buttonToolTip.SetToolTip(commentLabel, "Выделить слово или текст в книге, если к нему создан комментарий, \nон отобразится после слова \"Comment:\"");
        }
        private void DisplayCurrentPage() {
            currentPageLabel.Text = $"Page {currentPage + 1} of {pages.Length}";
            pageTextBox.Text = pages[currentPage];
        }
    }
}

/*Экзаменационное задание
Создать приложение «Читалка».
Приложение позволяет пользователю читать книги в разных форматах.
Пользователь приложения может:
▪ читать книги в разных форматах. Форматы, обязательные для поддержки: .txt, .epub, .rtf, .docx. При отображении 
- разбивать текст на страницы;
▪ переходить на следующую, предыдущую или выбранную страницу;
▪ просматривать локальную библиотеку;
▪ искать слово или текст в книге;
▪ добавлять комментарии к выделенному блоку текста;
▪ просматривать комментарии;
▪ ставить закладки в книгах;
▪ сохранять выделенный текст в «Избранном»;
▪ менять тему оформления приложения. Предусмотреть наличие нескольких встроенных тем.*/