﻿namespace BookReader
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.currentPageLabel = new System.Windows.Forms.Label();
            this.openButton = new System.Windows.Forms.Button();
            this.prevButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.goToButton = new System.Windows.Forms.Button();
            this.goToTextBox = new System.Windows.Forms.TextBox();
            this.pageTextBox = new System.Windows.Forms.TextBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.addCommentButton = new System.Windows.Forms.Button();
            this.commentLabel = new System.Windows.Forms.Label();
            this.commentTextBox = new System.Windows.Forms.TextBox();
            this.bookmarkLabel = new System.Windows.Forms.Label();
            this.setButton = new System.Windows.Forms.Button();
            this.goButton = new System.Windows.Forms.Button();
            this.favoritesLabel = new System.Windows.Forms.Label();
            this.addFavoritesButton = new System.Windows.Forms.Button();
            this.readFavoritesButton = new System.Windows.Forms.Button();
            this.viewLibraryButton = new System.Windows.Forms.Button();
            this.themesComboBox = new System.Windows.Forms.ComboBox();
            this.themesLabel = new System.Windows.Forms.Label();
            this.buttonToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // currentPageLabel
            // 
            this.currentPageLabel.AutoSize = true;
            this.currentPageLabel.Location = new System.Drawing.Point(6, 73);
            this.currentPageLabel.Name = "currentPageLabel";
            this.currentPageLabel.Size = new System.Drawing.Size(57, 13);
            this.currentPageLabel.TabIndex = 0;
            this.currentPageLabel.Text = "Num Page";
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(12, 10);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(75, 23);
            this.openButton.TabIndex = 1;
            this.openButton.Text = "Open File";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            this.openButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // prevButton
            // 
            this.prevButton.Location = new System.Drawing.Point(12, 89);
            this.prevButton.Name = "prevButton";
            this.prevButton.Size = new System.Drawing.Size(75, 23);
            this.prevButton.TabIndex = 2;
            this.prevButton.Text = "Prev Page";
            this.prevButton.UseVisualStyleBackColor = true;
            this.prevButton.Click += new System.EventHandler(this.prevButton_Click);
            this.prevButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(12, 118);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(75, 23);
            this.nextButton.TabIndex = 3;
            this.nextButton.Text = "Next Page";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            this.nextButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // goToButton
            // 
            this.goToButton.Location = new System.Drawing.Point(12, 147);
            this.goToButton.Name = "goToButton";
            this.goToButton.Size = new System.Drawing.Size(75, 23);
            this.goToButton.TabIndex = 4;
            this.goToButton.Text = "GoTo Page";
            this.goToButton.UseVisualStyleBackColor = true;
            this.goToButton.Click += new System.EventHandler(this.goToButton_Click);
            this.goToButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // goToTextBox
            // 
            this.goToTextBox.Location = new System.Drawing.Point(12, 176);
            this.goToTextBox.Name = "goToTextBox";
            this.goToTextBox.Size = new System.Drawing.Size(75, 20);
            this.goToTextBox.TabIndex = 5;
            this.goToTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pageTextBox
            // 
            this.pageTextBox.Location = new System.Drawing.Point(93, 10);
            this.pageTextBox.Multiline = true;
            this.pageTextBox.Name = "pageTextBox";
            this.pageTextBox.Size = new System.Drawing.Size(346, 503);
            this.pageTextBox.TabIndex = 6;
            this.pageTextBox.Click += new System.EventHandler(this.pageTextBox_SelectionChanged);
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(12, 516);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(75, 23);
            this.searchButton.TabIndex = 7;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            this.searchButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(93, 519);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(346, 20);
            this.searchTextBox.TabIndex = 8;
            // 
            // addCommentButton
            // 
            this.addCommentButton.Location = new System.Drawing.Point(445, 265);
            this.addCommentButton.Name = "addCommentButton";
            this.addCommentButton.Size = new System.Drawing.Size(86, 23);
            this.addCommentButton.TabIndex = 9;
            this.addCommentButton.Text = "Add Comment";
            this.addCommentButton.UseVisualStyleBackColor = true;
            this.addCommentButton.Click += new System.EventHandler(this.addCommentButton_Click);
            this.addCommentButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // commentLabel
            // 
            this.commentLabel.AutoSize = true;
            this.commentLabel.Location = new System.Drawing.Point(445, 10);
            this.commentLabel.MaximumSize = new System.Drawing.Size(86, 245);
            this.commentLabel.Name = "commentLabel";
            this.commentLabel.Size = new System.Drawing.Size(54, 13);
            this.commentLabel.TabIndex = 10;
            this.commentLabel.Text = "Comment:";
            this.commentLabel.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // commentTextBox
            // 
            this.commentTextBox.Location = new System.Drawing.Point(445, 294);
            this.commentTextBox.Multiline = true;
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(86, 245);
            this.commentTextBox.TabIndex = 11;
            // 
            // bookmarkLabel
            // 
            this.bookmarkLabel.AutoSize = true;
            this.bookmarkLabel.Location = new System.Drawing.Point(6, 208);
            this.bookmarkLabel.Name = "bookmarkLabel";
            this.bookmarkLabel.Size = new System.Drawing.Size(55, 13);
            this.bookmarkLabel.TabIndex = 12;
            this.bookmarkLabel.Text = "Bookmark";
            // 
            // setButton
            // 
            this.setButton.Location = new System.Drawing.Point(12, 224);
            this.setButton.Name = "setButton";
            this.setButton.Size = new System.Drawing.Size(75, 23);
            this.setButton.TabIndex = 13;
            this.setButton.Text = "Set";
            this.setButton.UseVisualStyleBackColor = true;
            this.setButton.Click += new System.EventHandler(this.setButton_Click);
            this.setButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // goButton
            // 
            this.goButton.Location = new System.Drawing.Point(12, 253);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(75, 23);
            this.goButton.TabIndex = 14;
            this.goButton.Text = "GoTo";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            this.goButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // favoritesLabel
            // 
            this.favoritesLabel.AutoSize = true;
            this.favoritesLabel.Location = new System.Drawing.Point(6, 287);
            this.favoritesLabel.Name = "favoritesLabel";
            this.favoritesLabel.Size = new System.Drawing.Size(50, 13);
            this.favoritesLabel.TabIndex = 15;
            this.favoritesLabel.Text = "Favorites";
            // 
            // addFavoritesButton
            // 
            this.addFavoritesButton.Location = new System.Drawing.Point(12, 303);
            this.addFavoritesButton.Name = "addFavoritesButton";
            this.addFavoritesButton.Size = new System.Drawing.Size(75, 23);
            this.addFavoritesButton.TabIndex = 16;
            this.addFavoritesButton.Text = "Add";
            this.addFavoritesButton.UseVisualStyleBackColor = true;
            this.addFavoritesButton.Click += new System.EventHandler(this.addFavoritesButton_Click);
            this.addFavoritesButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // readFavoritesButton
            // 
            this.readFavoritesButton.Location = new System.Drawing.Point(12, 332);
            this.readFavoritesButton.Name = "readFavoritesButton";
            this.readFavoritesButton.Size = new System.Drawing.Size(75, 23);
            this.readFavoritesButton.TabIndex = 17;
            this.readFavoritesButton.Text = "Read";
            this.readFavoritesButton.UseVisualStyleBackColor = true;
            this.readFavoritesButton.Click += new System.EventHandler(this.readFavoritesButton_Click);
            this.readFavoritesButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // viewLibraryButton
            // 
            this.viewLibraryButton.Location = new System.Drawing.Point(12, 39);
            this.viewLibraryButton.Name = "viewLibraryButton";
            this.viewLibraryButton.Size = new System.Drawing.Size(75, 23);
            this.viewLibraryButton.TabIndex = 18;
            this.viewLibraryButton.Text = "View Library";
            this.viewLibraryButton.UseVisualStyleBackColor = true;
            this.viewLibraryButton.Click += new System.EventHandler(this.viewLibraryButton_Click);
            this.viewLibraryButton.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // themesComboBox
            // 
            this.themesComboBox.FormattingEnabled = true;
            this.themesComboBox.Location = new System.Drawing.Point(12, 382);
            this.themesComboBox.Name = "themesComboBox";
            this.themesComboBox.Size = new System.Drawing.Size(75, 21);
            this.themesComboBox.TabIndex = 19;
            this.themesComboBox.SelectedIndexChanged += new System.EventHandler(this.themesComboBox_SelectedIndexChanged);
            this.themesComboBox.MouseHover += new System.EventHandler(this.Control_MouseHover);
            // 
            // themesLabel
            // 
            this.themesLabel.AutoSize = true;
            this.themesLabel.Location = new System.Drawing.Point(6, 366);
            this.themesLabel.Name = "themesLabel";
            this.themesLabel.Size = new System.Drawing.Size(45, 13);
            this.themesLabel.TabIndex = 20;
            this.themesLabel.Text = "Themes";
            // 
            // richTextBox
            // 
            this.richTextBox.Location = new System.Drawing.Point(445, 239);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(86, 20);
            this.richTextBox.TabIndex = 21;
            this.richTextBox.Text = "";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 545);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.themesLabel);
            this.Controls.Add(this.themesComboBox);
            this.Controls.Add(this.viewLibraryButton);
            this.Controls.Add(this.readFavoritesButton);
            this.Controls.Add(this.addFavoritesButton);
            this.Controls.Add(this.favoritesLabel);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.setButton);
            this.Controls.Add(this.bookmarkLabel);
            this.Controls.Add(this.commentTextBox);
            this.Controls.Add(this.commentLabel);
            this.Controls.Add(this.addCommentButton);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.pageTextBox);
            this.Controls.Add(this.goToTextBox);
            this.Controls.Add(this.goToButton);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.prevButton);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.currentPageLabel);
            this.Name = "MainForm";
            this.Text = "BookReader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label currentPageLabel;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.Button prevButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Button goToButton;
        private System.Windows.Forms.TextBox goToTextBox;
        private System.Windows.Forms.TextBox pageTextBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.Button addCommentButton;
        private System.Windows.Forms.Label commentLabel;
        private System.Windows.Forms.TextBox commentTextBox;
        private System.Windows.Forms.Label bookmarkLabel;
        private System.Windows.Forms.Button setButton;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.Label favoritesLabel;
        private System.Windows.Forms.Button addFavoritesButton;
        private System.Windows.Forms.Button readFavoritesButton;
        private System.Windows.Forms.Button viewLibraryButton;
        private System.Windows.Forms.ComboBox themesComboBox;
        private System.Windows.Forms.Label themesLabel;
        private System.Windows.Forms.ToolTip buttonToolTip;
        private System.Windows.Forms.RichTextBox richTextBox;
    }
}

