﻿namespace BestOil
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.toCount = new System.Windows.Forms.Button();
            this.HotDogCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButtonSum = new System.Windows.Forms.RadioButton();
            this.radioButtonCount = new System.Windows.Forms.RadioButton();
            this.textBoxRadioCount = new System.Windows.Forms.TextBox();
            this.textBoxRadioSum = new System.Windows.Forms.TextBox();
            this.textBoxFuelPrice = new System.Windows.Forms.TextBox();
            this.comboBoxFuel = new System.Windows.Forms.ComboBox();
            this.groupBoxFuel = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.toPayGasStation = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CokoColaCount = new System.Windows.Forms.TextBox();
            this.CokoColaPrice = new System.Windows.Forms.TextBox();
            this.FrenchFriesCount = new System.Windows.Forms.TextBox();
            this.FrenchFriesPrice = new System.Windows.Forms.TextBox();
            this.HamburgerCount = new System.Windows.Forms.TextBox();
            this.HamburgerPrice = new System.Windows.Forms.TextBox();
            this.HotDogCount = new System.Windows.Forms.TextBox();
            this.HotDogPrice = new System.Windows.Forms.TextBox();
            this.CokoColaCheckBox = new System.Windows.Forms.CheckBox();
            this.FrenchFriesCheckBox = new System.Windows.Forms.CheckBox();
            this.HamburgerCheckBox = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.toPayCafe = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toPayTotal = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.dataToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dayOfWeekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.colorPanel = new System.Windows.Forms.Panel();
            this.okButton = new System.Windows.Forms.Button();
            this.bLabel = new System.Windows.Forms.Label();
            this.gLabel = new System.Windows.Forms.Label();
            this.rLabel = new System.Windows.Forms.Label();
            this.bTrackBar = new System.Windows.Forms.TrackBar();
            this.gTrackBar = new System.Windows.Forms.TrackBar();
            this.rTrackBar = new System.Windows.Forms.TrackBar();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBoxFuel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.colorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(107, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Цена";
            // 
            // toCount
            // 
            this.toCount.ForeColor = System.Drawing.Color.Black;
            this.toCount.Location = new System.Drawing.Point(78, 24);
            this.toCount.Name = "toCount";
            this.toCount.Size = new System.Drawing.Size(148, 60);
            this.toCount.TabIndex = 1;
            this.toCount.Text = "Рассчитать";
            this.toCount.UseVisualStyleBackColor = true;
            this.toCount.MouseHover += new System.EventHandler(this.toCount_MouseHover);
            // 
            // HotDogCheckBox
            // 
            this.HotDogCheckBox.AutoSize = true;
            this.HotDogCheckBox.ForeColor = System.Drawing.Color.Black;
            this.HotDogCheckBox.Location = new System.Drawing.Point(6, 37);
            this.HotDogCheckBox.Name = "HotDogCheckBox";
            this.HotDogCheckBox.Size = new System.Drawing.Size(64, 17);
            this.HotDogCheckBox.TabIndex = 2;
            this.HotDogCheckBox.Text = "Хот-дог";
            this.HotDogCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.textBoxRadioCount);
            this.groupBox1.Controls.Add(this.textBoxRadioSum);
            this.groupBox1.Controls.Add(this.textBoxFuelPrice);
            this.groupBox1.Controls.Add(this.comboBoxFuel);
            this.groupBox1.Controls.Add(this.groupBoxFuel);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(230, 265);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Автозаправка";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(196, 161);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "руб.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(196, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "л.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Цена";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(6, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Топливо";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButtonSum);
            this.groupBox6.Controls.Add(this.radioButtonCount);
            this.groupBox6.Location = new System.Drawing.Point(6, 115);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(103, 64);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            // 
            // radioButtonSum
            // 
            this.radioButtonSum.AutoSize = true;
            this.radioButtonSum.ForeColor = System.Drawing.Color.Black;
            this.radioButtonSum.Location = new System.Drawing.Point(9, 38);
            this.radioButtonSum.Name = "radioButtonSum";
            this.radioButtonSum.Size = new System.Drawing.Size(59, 17);
            this.radioButtonSum.TabIndex = 1;
            this.radioButtonSum.Text = "Сумма";
            this.radioButtonSum.UseVisualStyleBackColor = true;
            // 
            // radioButtonCount
            // 
            this.radioButtonCount.AutoSize = true;
            this.radioButtonCount.Checked = true;
            this.radioButtonCount.ForeColor = System.Drawing.Color.Black;
            this.radioButtonCount.Location = new System.Drawing.Point(9, 9);
            this.radioButtonCount.Name = "radioButtonCount";
            this.radioButtonCount.Size = new System.Drawing.Size(84, 17);
            this.radioButtonCount.TabIndex = 0;
            this.radioButtonCount.TabStop = true;
            this.radioButtonCount.Text = "Количество";
            this.radioButtonCount.UseVisualStyleBackColor = true;
            // 
            // textBoxRadioCount
            // 
            this.textBoxRadioCount.Location = new System.Drawing.Point(119, 121);
            this.textBoxRadioCount.Name = "textBoxRadioCount";
            this.textBoxRadioCount.Size = new System.Drawing.Size(69, 20);
            this.textBoxRadioCount.TabIndex = 14;
            this.textBoxRadioCount.Text = "0,00";
            // 
            // textBoxRadioSum
            // 
            this.textBoxRadioSum.Location = new System.Drawing.Point(119, 157);
            this.textBoxRadioSum.Name = "textBoxRadioSum";
            this.textBoxRadioSum.ReadOnly = true;
            this.textBoxRadioSum.Size = new System.Drawing.Size(69, 20);
            this.textBoxRadioSum.TabIndex = 13;
            this.textBoxRadioSum.Text = "0,00";
            // 
            // textBoxFuelPrice
            // 
            this.textBoxFuelPrice.Location = new System.Drawing.Point(72, 79);
            this.textBoxFuelPrice.Name = "textBoxFuelPrice";
            this.textBoxFuelPrice.ReadOnly = true;
            this.textBoxFuelPrice.Size = new System.Drawing.Size(121, 20);
            this.textBoxFuelPrice.TabIndex = 11;
            // 
            // comboBoxFuel
            // 
            this.comboBoxFuel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFuel.FormattingEnabled = true;
            this.comboBoxFuel.Items.AddRange(new object[] {
            "АИ-92",
            "АИ-95",
            "АИ-98",
            "Газ",
            "Дизтопливо"});
            this.comboBoxFuel.Location = new System.Drawing.Point(72, 36);
            this.comboBoxFuel.Name = "comboBoxFuel";
            this.comboBoxFuel.Size = new System.Drawing.Size(121, 21);
            this.comboBoxFuel.TabIndex = 6;
            // 
            // groupBoxFuel
            // 
            this.groupBoxFuel.Controls.Add(this.label5);
            this.groupBoxFuel.Controls.Add(this.toPayGasStation);
            this.groupBoxFuel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBoxFuel.Location = new System.Drawing.Point(6, 185);
            this.groupBoxFuel.Name = "groupBoxFuel";
            this.groupBoxFuel.Size = new System.Drawing.Size(217, 74);
            this.groupBoxFuel.TabIndex = 5;
            this.groupBoxFuel.TabStop = false;
            this.groupBoxFuel.Text = "К оплате";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(149, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "руб.";
            // 
            // toPayGasStation
            // 
            this.toPayGasStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toPayGasStation.ForeColor = System.Drawing.Color.Black;
            this.toPayGasStation.Location = new System.Drawing.Point(6, 16);
            this.toPayGasStation.Name = "toPayGasStation";
            this.toPayGasStation.Size = new System.Drawing.Size(136, 55);
            this.toPayGasStation.TabIndex = 11;
            this.toPayGasStation.Text = "0,00";
            this.toPayGasStation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CokoColaCount);
            this.groupBox2.Controls.Add(this.CokoColaPrice);
            this.groupBox2.Controls.Add(this.FrenchFriesCount);
            this.groupBox2.Controls.Add(this.FrenchFriesPrice);
            this.groupBox2.Controls.Add(this.HamburgerCount);
            this.groupBox2.Controls.Add(this.HamburgerPrice);
            this.groupBox2.Controls.Add(this.HotDogCount);
            this.groupBox2.Controls.Add(this.HotDogPrice);
            this.groupBox2.Controls.Add(this.CokoColaCheckBox);
            this.groupBox2.Controls.Add(this.FrenchFriesCheckBox);
            this.groupBox2.Controls.Add(this.HamburgerCheckBox);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.HotDogCheckBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox2.Location = new System.Drawing.Point(263, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(219, 265);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Мини-Кафе";
            // 
            // CokoColaCount
            // 
            this.CokoColaCount.Location = new System.Drawing.Point(160, 127);
            this.CokoColaCount.Name = "CokoColaCount";
            this.CokoColaCount.ReadOnly = true;
            this.CokoColaCount.Size = new System.Drawing.Size(48, 20);
            this.CokoColaCount.TabIndex = 23;
            this.CokoColaCount.Text = "0,00";
            // 
            // CokoColaPrice
            // 
            this.CokoColaPrice.Location = new System.Drawing.Point(106, 127);
            this.CokoColaPrice.Name = "CokoColaPrice";
            this.CokoColaPrice.ReadOnly = true;
            this.CokoColaPrice.Size = new System.Drawing.Size(48, 20);
            this.CokoColaPrice.TabIndex = 22;
            this.CokoColaPrice.Text = "75,00";
            // 
            // FrenchFriesCount
            // 
            this.FrenchFriesCount.Location = new System.Drawing.Point(160, 98);
            this.FrenchFriesCount.Name = "FrenchFriesCount";
            this.FrenchFriesCount.ReadOnly = true;
            this.FrenchFriesCount.Size = new System.Drawing.Size(48, 20);
            this.FrenchFriesCount.TabIndex = 21;
            this.FrenchFriesCount.Text = "0,00";
            // 
            // FrenchFriesPrice
            // 
            this.FrenchFriesPrice.Location = new System.Drawing.Point(106, 98);
            this.FrenchFriesPrice.Name = "FrenchFriesPrice";
            this.FrenchFriesPrice.ReadOnly = true;
            this.FrenchFriesPrice.Size = new System.Drawing.Size(48, 20);
            this.FrenchFriesPrice.TabIndex = 20;
            this.FrenchFriesPrice.Text = "130,00";
            // 
            // HamburgerCount
            // 
            this.HamburgerCount.Location = new System.Drawing.Point(160, 67);
            this.HamburgerCount.Name = "HamburgerCount";
            this.HamburgerCount.ReadOnly = true;
            this.HamburgerCount.Size = new System.Drawing.Size(48, 20);
            this.HamburgerCount.TabIndex = 19;
            this.HamburgerCount.Text = "0,00";
            // 
            // HamburgerPrice
            // 
            this.HamburgerPrice.Location = new System.Drawing.Point(106, 67);
            this.HamburgerPrice.Name = "HamburgerPrice";
            this.HamburgerPrice.ReadOnly = true;
            this.HamburgerPrice.Size = new System.Drawing.Size(48, 20);
            this.HamburgerPrice.TabIndex = 18;
            this.HamburgerPrice.Text = "117,00";
            // 
            // HotDogCount
            // 
            this.HotDogCount.Location = new System.Drawing.Point(160, 37);
            this.HotDogCount.Name = "HotDogCount";
            this.HotDogCount.ReadOnly = true;
            this.HotDogCount.Size = new System.Drawing.Size(48, 20);
            this.HotDogCount.TabIndex = 17;
            this.HotDogCount.Text = "0,00";
            // 
            // HotDogPrice
            // 
            this.HotDogPrice.Location = new System.Drawing.Point(106, 37);
            this.HotDogPrice.Name = "HotDogPrice";
            this.HotDogPrice.ReadOnly = true;
            this.HotDogPrice.Size = new System.Drawing.Size(48, 20);
            this.HotDogPrice.TabIndex = 16;
            this.HotDogPrice.Text = "129,00";
            // 
            // CokoColaCheckBox
            // 
            this.CokoColaCheckBox.AutoSize = true;
            this.CokoColaCheckBox.ForeColor = System.Drawing.Color.Black;
            this.CokoColaCheckBox.Location = new System.Drawing.Point(6, 127);
            this.CokoColaCheckBox.Name = "CokoColaCheckBox";
            this.CokoColaCheckBox.Size = new System.Drawing.Size(75, 17);
            this.CokoColaCheckBox.TabIndex = 10;
            this.CokoColaCheckBox.Text = "Coka-Cola";
            this.CokoColaCheckBox.UseVisualStyleBackColor = true;
            // 
            // FrenchFriesCheckBox
            // 
            this.FrenchFriesCheckBox.AutoSize = true;
            this.FrenchFriesCheckBox.ForeColor = System.Drawing.Color.Black;
            this.FrenchFriesCheckBox.Location = new System.Drawing.Point(6, 98);
            this.FrenchFriesCheckBox.Name = "FrenchFriesCheckBox";
            this.FrenchFriesCheckBox.Size = new System.Drawing.Size(99, 17);
            this.FrenchFriesCheckBox.TabIndex = 9;
            this.FrenchFriesCheckBox.Text = "Картошка фри";
            this.FrenchFriesCheckBox.UseVisualStyleBackColor = true;
            // 
            // HamburgerCheckBox
            // 
            this.HamburgerCheckBox.AutoSize = true;
            this.HamburgerCheckBox.ForeColor = System.Drawing.Color.Black;
            this.HamburgerCheckBox.Location = new System.Drawing.Point(6, 67);
            this.HamburgerCheckBox.Name = "HamburgerCheckBox";
            this.HamburgerCheckBox.Size = new System.Drawing.Size(80, 17);
            this.HamburgerCheckBox.TabIndex = 8;
            this.HamburgerCheckBox.Text = "Гамбургер";
            this.HamburgerCheckBox.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(147, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Количество";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.toPayCafe);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox4.Location = new System.Drawing.Point(6, 185);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(207, 74);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "К оплате";
            // 
            // toPayCafe
            // 
            this.toPayCafe.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toPayCafe.ForeColor = System.Drawing.Color.Black;
            this.toPayCafe.Location = new System.Drawing.Point(6, 16);
            this.toPayCafe.Name = "toPayCafe";
            this.toPayCafe.Size = new System.Drawing.Size(136, 55);
            this.toPayCafe.TabIndex = 13;
            this.toPayCafe.Text = "0,00";
            this.toPayCafe.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(149, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "руб.";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.toPayTotal);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.toCount);
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox5.Location = new System.Drawing.Point(12, 292);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(455, 96);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ВСЕГО к оплате";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BestOil.Properties.Resources.BestOilLogo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // toPayTotal
            // 
            this.toPayTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toPayTotal.ForeColor = System.Drawing.Color.Black;
            this.toPayTotal.Location = new System.Drawing.Point(226, 24);
            this.toPayTotal.Name = "toPayTotal";
            this.toPayTotal.Size = new System.Drawing.Size(184, 60);
            this.toPayTotal.TabIndex = 12;
            this.toPayTotal.Text = "0,00";
            this.toPayTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(416, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "руб.";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 2000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick_1);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataToolStripStatusLabel,
            this.toolStripDropDownButton1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 401);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(494, 22);
            this.statusStrip1.TabIndex = 18;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // dataToolStripStatusLabel
            // 
            this.dataToolStripStatusLabel.Name = "dataToolStripStatusLabel";
            this.dataToolStripStatusLabel.Size = new System.Drawing.Size(60, 17);
            this.dataToolStripStatusLabel.Text = "Data/time";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorToolStripMenuItem,
            this.dayOfWeekToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.colorToolStripMenuItem.Text = "Цвет фона";
            this.colorToolStripMenuItem.Click += new System.EventHandler(this.colorToolStripMenuItem_Click);
            // 
            // dayOfWeekToolStripMenuItem
            // 
            this.dayOfWeekToolStripMenuItem.Name = "dayOfWeekToolStripMenuItem";
            this.dayOfWeekToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.dayOfWeekToolStripMenuItem.Text = "День недели";
            // 
            // colorPanel
            // 
            this.colorPanel.BackColor = System.Drawing.Color.Yellow;
            this.colorPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.colorPanel.Controls.Add(this.okButton);
            this.colorPanel.Controls.Add(this.bLabel);
            this.colorPanel.Controls.Add(this.gLabel);
            this.colorPanel.Controls.Add(this.rLabel);
            this.colorPanel.Controls.Add(this.bTrackBar);
            this.colorPanel.Controls.Add(this.gTrackBar);
            this.colorPanel.Controls.Add(this.rTrackBar);
            this.colorPanel.Location = new System.Drawing.Point(150, 114);
            this.colorPanel.Name = "colorPanel";
            this.colorPanel.Size = new System.Drawing.Size(194, 195);
            this.colorPanel.TabIndex = 19;
            this.colorPanel.Visible = false;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(55, 158);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 6;
            this.okButton.Text = "Принять";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click_1);
            // 
            // bLabel
            // 
            this.bLabel.AutoSize = true;
            this.bLabel.Location = new System.Drawing.Point(15, 120);
            this.bLabel.Name = "bLabel";
            this.bLabel.Size = new System.Drawing.Size(14, 13);
            this.bLabel.TabIndex = 5;
            this.bLabel.Text = "B";
            // 
            // gLabel
            // 
            this.gLabel.AutoSize = true;
            this.gLabel.Location = new System.Drawing.Point(15, 70);
            this.gLabel.Name = "gLabel";
            this.gLabel.Size = new System.Drawing.Size(15, 13);
            this.gLabel.TabIndex = 4;
            this.gLabel.Text = "G";
            // 
            // rLabel
            // 
            this.rLabel.AutoSize = true;
            this.rLabel.Location = new System.Drawing.Point(15, 17);
            this.rLabel.Name = "rLabel";
            this.rLabel.Size = new System.Drawing.Size(15, 13);
            this.rLabel.TabIndex = 3;
            this.rLabel.Text = "R";
            // 
            // bTrackBar
            // 
            this.bTrackBar.Location = new System.Drawing.Point(52, 116);
            this.bTrackBar.Maximum = 255;
            this.bTrackBar.Name = "bTrackBar";
            this.bTrackBar.Size = new System.Drawing.Size(128, 45);
            this.bTrackBar.TabIndex = 2;
            this.bTrackBar.ValueChanged += new System.EventHandler(this.AllTrackBar_ValueChanged);
            // 
            // gTrackBar
            // 
            this.gTrackBar.Location = new System.Drawing.Point(52, 65);
            this.gTrackBar.Maximum = 255;
            this.gTrackBar.Name = "gTrackBar";
            this.gTrackBar.Size = new System.Drawing.Size(128, 45);
            this.gTrackBar.TabIndex = 1;
            this.gTrackBar.ValueChanged += new System.EventHandler(this.AllTrackBar_ValueChanged);
            // 
            // rTrackBar
            // 
            this.rTrackBar.Location = new System.Drawing.Point(52, 14);
            this.rTrackBar.Maximum = 255;
            this.rTrackBar.Name = "rTrackBar";
            this.rTrackBar.Size = new System.Drawing.Size(128, 45);
            this.rTrackBar.TabIndex = 0;
            this.rTrackBar.ValueChanged += new System.EventHandler(this.AllTrackBar_ValueChanged);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "BestOil";
            this.notifyIcon1.Visible = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 423);
            this.Controls.Add(this.colorPanel);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BestOil";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBoxFuel.ResumeLayout(false);
            this.groupBoxFuel.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.colorPanel.ResumeLayout(false);
            this.colorPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button toCount;
        private System.Windows.Forms.CheckBox HotDogCheckBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBoxFuel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label toPayGasStation;
        private System.Windows.Forms.CheckBox CokoColaCheckBox;
        private System.Windows.Forms.CheckBox FrenchFriesCheckBox;
        private System.Windows.Forms.CheckBox HamburgerCheckBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label toPayCafe;
        private System.Windows.Forms.Label toPayTotal;
        private System.Windows.Forms.ComboBox comboBoxFuel;
        private System.Windows.Forms.TextBox textBoxRadioSum;
        private System.Windows.Forms.TextBox textBoxFuelPrice;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButtonSum;
        private System.Windows.Forms.RadioButton radioButtonCount;
        private System.Windows.Forms.TextBox textBoxRadioCount;
        private System.Windows.Forms.TextBox CokoColaCount;
        private System.Windows.Forms.TextBox CokoColaPrice;
        private System.Windows.Forms.TextBox FrenchFriesCount;
        private System.Windows.Forms.TextBox FrenchFriesPrice;
        private System.Windows.Forms.TextBox HamburgerCount;
        private System.Windows.Forms.TextBox HamburgerPrice;
        private System.Windows.Forms.TextBox HotDogCount;
        private System.Windows.Forms.TextBox HotDogPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel dataToolStripStatusLabel;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dayOfWeekToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel colorPanel;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label bLabel;
        private System.Windows.Forms.Label gLabel;
        private System.Windows.Forms.Label rLabel;
        private System.Windows.Forms.TrackBar bTrackBar;
        private System.Windows.Forms.TrackBar gTrackBar;
        private System.Windows.Forms.TrackBar rTrackBar;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}

