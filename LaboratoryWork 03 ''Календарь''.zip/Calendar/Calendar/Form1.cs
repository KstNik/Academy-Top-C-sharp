﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            label1.Text = dateTimePicker1.Value.ToString("dd.MM.yyyy");
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) {
            label1.Text = dateTimePicker1.Value.ToString("dd.MM.yyyy");
        }
        private void button1_Click(object sender, EventArgs e) {
            dateTimePicker1.Focus();
            SendKeys.Send("{F4}");
        }
    }
}