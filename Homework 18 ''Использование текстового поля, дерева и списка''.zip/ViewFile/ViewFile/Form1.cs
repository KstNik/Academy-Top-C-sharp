﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ViewFile {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink; // запрет изменения размера
            this.MaximizeBox = false; // запрет развёртывания на весь экран
            AllowDrop = true;
            richTextBox1.AllowDrop = true;
            richTextBox1.DragEnter += RichTextBox1_DragEnter;
            richTextBox1.DragDrop += RichTextBox1_DragDrop;
        }
        private void RichTextBox1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }
        private void RichTextBox1_DragDrop(object sender, DragEventArgs e) {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files) {
                if (File.Exists(file))
                    richTextBox1.Text = File.ReadAllText(file);
            }
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e) {
            OpenFileDialog openFileDialog1 = new OpenFileDialog {
                Title = "Open Text File",
                CheckFileExists = true,
                CheckPathExists = true,
                DefaultExt = "txt",
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 2,
                RestoreDirectory = true,
                ReadOnlyChecked = true,
                ShowReadOnly = true
            };
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                string filePath = openFileDialog1.FileName;
                richTextBox1.Text = File.ReadAllText(filePath);
            }
        }
    }
}

/*Задание 1. Создайте редактор на базе RichTextBox и добавьте в него возможность выбора 
из каталога и просмотра содержимого файла перетаскиванием файла на поле редактора.*/