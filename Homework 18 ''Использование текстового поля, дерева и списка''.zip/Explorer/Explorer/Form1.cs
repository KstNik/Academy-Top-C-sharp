﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explorer {
    public partial class Form1 : Form {
        OpenFileDialog openFile = null;
        public Form1() {
            InitializeComponent();
            DirectoryTreeNode();
            treeView1.BeforeExpand += TreeView_AfterSelect;
            treeView1.NodeMouseClick += TreeView1_NodeMouseClick;
        }
        private void TreeView_AfterSelect(object sender, TreeViewCancelEventArgs e) {
            e.Node.Nodes.Clear();
            try {
                if (Directory.Exists(e.Node.FullPath)) {
                    string[] dir = Directory.GetDirectories(e.Node.FullPath);
                    for (int i = 0; i < dir.Length; i++) {
                        TreeNode dirNode = new TreeNode(new DirectoryInfo(dir[i]).Name);
                        FillTreeNode(dirNode, dir[i]);
                        e.Node.Nodes.Add(dirNode);
                    }
                    string[] file = Directory.GetFiles(e.Node.FullPath);
                    for (int i = 0; i < file.Length; i++) {
                        TreeNode fileNode = new TreeNode(new DirectoryInfo(file[i]).Name);
                        e.Node.Nodes.Add(fileNode);
                    }
                }
            }
            catch (Exception exception) {
                MessageBox.Show($"{exception.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Refresh();
            }
        }
        private void DirectoryTreeNode() {
            try {
                foreach (DriveInfo drive in DriveInfo.GetDrives()) {
                    TreeNode treeNode = new TreeNode(drive.Name);
                    FillTreeNode(treeNode, drive.Name);
                    treeView1.Nodes.Add(treeNode);
                }
            }
            catch (Exception exception) {
                MessageBox.Show($"{exception.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Refresh();
            }
        }
        private void FillTreeNode(TreeNode driveNode, string path) {
            try {
                string[] dirs = Directory.GetDirectories(path); // добавляем + если есть папки
                foreach (string dir in dirs) {
                    TreeNode dirNode = new TreeNode(dir.Remove(0, dir.LastIndexOf("\\") + 1));
                    driveNode.Nodes.Add(dirNode);
                }
                string[] files = Directory.GetFiles(path); // добавляем + когда нет папок, а есть только файлы
                foreach (string file in files) {
                    TreeNode fileNode = new TreeNode(new DirectoryInfo(file).Name);
                    driveNode.Nodes.Add(fileNode);
                }
            }
            catch (Exception) { }
        }
        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
            DisplayProperties(e.Node.FullPath);
        }
        private void DisplayProperties(string path) {
            try {
                if (File.Exists(path))
                {
                    FileInfo fileInfo = new FileInfo(path);
                    listView1.Items.Clear();
                    listView1.Items.Add(fileInfo.Name);
                    listView1.Items.Add(fileInfo.Extension);
                    listView1.Items.Add(fileInfo.Length.ToString());
                    listView1.Items.Add(fileInfo.CreationTime.ToString());
                    listView1.Items.Add(fileInfo.Attributes.ToString());
                }
                else if (Directory.Exists(path)) {
                    DirectoryInfo dirInfo = new DirectoryInfo(path);
                    listView1.Items.Clear();
                    listView1.Items.Add(dirInfo.Name);
                    listView1.Items.Add("Folder");
                    listView1.Items.Add(dirInfo.CreationTime.ToString());
                    listView1.Items.Add(dirInfo.Attributes.ToString());
                    int fileCount = Directory.GetFiles(path).Length;
                    int dirCount = Directory.GetDirectories(path).Length;
                    listView1.Items.Add(fileCount.ToString());
                    listView1.Items.Add(dirCount.ToString());
                }
            }
            catch (Exception exception) {
                MessageBox.Show($"{exception.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

/*Задание 2. Создать приложение отображающее информацию о файлах и директориях с использованием 
элементов управления ListView и TreeView: отображение файлов и папок всех логических дисков с 
помощью TreeView, при выборе файла или папки в ListView отображаются все свойства (дата создания, 
размер, тип, количество файлов для папки, атрибуты и т.д.).*/