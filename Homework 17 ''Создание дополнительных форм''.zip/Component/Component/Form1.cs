﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Component {
    public partial class OrderForm : Form {
        Component newComponet;
        List<Component> Comp;
        public OrderForm() {
            InitializeComponent();
        }
        protected override void OnLoad(EventArgs e) {
            Comp = new List<Component>();
            newComponet = null;
            Component c = new Component(
                "Материнская плата GIGABYTE Z790 AORUS ELITE AX",
                "LGA 1700, Intel Z790, 4xDDR5-4800 МГц, 3xPCI-Ex16, 4xM.2, Standard-ATX",
                "Лучшая в своей ценовой категории по совокупности характеристик, есть всё что нужно для обычного пользователя",
                (float)28999.00
                );
            Comp.Add(c);
            of_cb_components.Items.Add(c.Title);
            c = new Component(
                "Процессор Intel Core i9-13900K OEM",
                "LGA 1700, 8P x 3 ГГц, 16E x 2.2 ГГц, L2 - 32 МБ, L3 - 36 МБ, 2 х DDR4, DDR5-5600 МГц, Intel UHD Graphics 770, TDP 253 Вт",
                "Отличный процессор, при работе с графикой и физическими симуляциями, выдает прекрасную производительность",
                (float)69999.00
                );
            Comp.Add(c);
            of_cb_components.Items.Add(c.Title);
            of_cb_components.SelectedIndexChanged += Of_cb_components_SelectedIndexChanged;
            of_b_add.Click += Of_b_add_Click;
            of_lb_selectedComp.DoubleClick += Of_lb_selectedComp_DoubleClick;
            of_b_close.Click += Of_b_close_Click;
            of_b_createComp.Click += Of_b_createComp_Click;
            of_b_edit.Click += Of_b_edit_Click;
        }
        private void Of_b_edit_Click(object sender, EventArgs e) { // нажатие кнопки редактировать
            int index = of_cb_components.SelectedIndex; // позиция выбранного компонента
            int n = 0; int jj; // счетчики
            int[] j = new int[1];
            string oldTitle = of_cb_components.SelectedItem.ToString();
            string newTitle = "";
            bool isEdit = false; // флаг было ли редактирование
            foreach (Component item in Comp) {
                if (item.Title == oldTitle) {
                    CEdit f = new CEdit(item, false);
                    if (f.ShowDialog() == DialogResult.OK) { // изменение компонента в выпадающем списке
                        of_cb_components.Items.RemoveAt(index);
                        of_cb_components.Items.Insert(index, item.Title);
                        Comp.RemoveAt(n); // изменение компонента в обще списке
                        Comp.Insert(n, item);
                        newTitle = item.Title;
                        of_cb_components.SelectedIndex = -1;
                        of_b_add.Enabled = false;
                        of_b_edit.Enabled = false;
                        of_rtb_characteristics.Clear();
                        of_rtb_description.Clear();
                        of_tb_price.Clear();
                        isEdit = true;
                    }
                    break;
                }
                n++;
            }
            n = 0;
            jj = 1;
            if (isEdit) { // если изменения были
                foreach (string title in of_lb_selectedComp.Items) { // компонент был добавлен изменение в списке
                    if (title == oldTitle) {
                        Array.Resize(ref j, jj);
                        j[jj - 1] = n;
                        jj++;
                    }
                    n++;
                }
                ChangeListItem(j, newTitle);  // изменение в списке добавленных компонентов
                SetTotalPrice(); // пересчёт общей цены
            }
        }
        private void Of_b_createComp_Click(object sender, EventArgs e) { // нажатие кнопки создания
            newComponet = new Component();
            CEdit f = new CEdit(newComponet, true);
            if (f.ShowDialog() == DialogResult.OK) {
                Comp.Add(newComponet);
                of_cb_components.Items.Add(newComponet.Title);
                int n = 0;
                foreach (string title in of_cb_components.Items) {
                    if (title == newComponet.Title)
                        break;
                    n++;
                }
                of_cb_components.SelectedIndex = n;
            }
        }
        private void Of_b_close_Click(object sender, EventArgs e) { // нажатие кнопки закрытия
            this.Close();
        }
        private void Of_lb_selectedComp_DoubleClick(object sender, EventArgs e) { // информация о товаре на котором было двойное нажатие
            if (of_lb_selectedComp.SelectedIndex != -1) {
                foreach (Component item in Comp) {
                    if (item.Title == of_lb_selectedComp.SelectedItem.ToString())
                    {
                        MessageBox.Show(item.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }
        private void Of_b_add_Click(object sender, EventArgs e) { // нажатие кнопки добавить
            of_lb_selectedComp.Items.Add(of_cb_components.SelectedItem.ToString());
            SetTotalPrice();
        }
        private void Of_cb_components_SelectedIndexChanged(object sender, EventArgs e) { // обработка выбора в Combobox
            if (of_cb_components.SelectedIndex >= 0) {
                of_b_add.Enabled = true;
                of_b_edit.Enabled = true;
                foreach (Component item in Comp) {
                    if (item.Title == of_cb_components.SelectedItem.ToString()) {
                        of_rtb_characteristics.Text = item.Characteristic;
                        of_rtb_description.Text = item.Description;
                        of_tb_price.Text = item.Price.ToString();
                    }
                }
            }
            else {
                of_b_add.Enabled = false;
                of_b_edit.Enabled = false;
            }
        }
        private void SetTotalPrice() { // подсчёт стоимости добавленного товара и вывод результата
            float res = 0;
            if (of_lb_selectedComp.Items.Count > 0) {
                foreach (string c in of_lb_selectedComp.Items) {
                    foreach (Component item in Comp) {
                        if (c == item.Title)
                            res += item.Price;
                    }
                }
            }
            of_l_totalPrice.Text = res.ToString();
        }
        private float GetComponentPrice(string component) { // возвращение цены компонента, если такой существует или -1 – если не найден
            foreach (Component item in Comp) {
                if (item.Title == component)
                    return item.Price;
            }
            return -1;
        }
        private void ChangeListItem(int[] positions, string newTitle) { // изменение значения в списке
            foreach (int position in positions) {
                if (position > 0) {
                    of_lb_selectedComp.Items.RemoveAt(position);
                    of_lb_selectedComp.Items.Insert(position, newTitle);
                }
            }
        }
    }
}

/*Задание 2. Фирма продаёт составляющие компьютера. Первая форма отвечает за учёт продаж, 
вторая за добавление и редактирование составляющих.
Первая форма: Список, выпадающий список, текстовое поле, кнопка вызова второй формы. 
В выпадающем списке появляются наименования всех товаров, которые в наличие в магазине. 
Пользователь выбирает товар, в текстовом окне, которое нельзя редактировать, появляется 
цена. Пользователь нажимает «добавить» и товар добавляется в список продаж. Также должно 
быть окошко, которое выводит общую стоимость.
Вторая форма: Информация о комплектующих (наименование, характеристика, описание и цена) 
вводится в текстовые поля; в список добавляется текстовая строка, содержащая информацию 
о товаре, кроме цены, цена в списке не видна, но содержится; также комплектующие можно 
редактировать.*/