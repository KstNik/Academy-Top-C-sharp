﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SearchFiles {
    public partial class SearchForm : Form {
        public SearchForm() {
            InitializeComponent();
        }
        protected override void OnLoad(EventArgs e) {
            sf_b_openFolder.Click += Sf_b_openFolder_Click;
            sf_tb_masks.TextChanged += Sf_tb_masks_TextChanged;
            sf_b_startSearch.Click += Sf_b_startSearch_Click;
        }
        private void Sf_b_startSearch_Click(object sender, EventArgs e) { // запуск процедуры поиска файлов
            sf_lb_files.Items.Clear(); // очистка списка
            String[] masks = sf_tb_masks.Text.Split('.').ToArray(); // разбивка введённой маски на массив для проверки
            if (masks.Count() != 2 || masks[1] == "") {
                MessageBox.Show("Вы ввели не правильную маску.\rМаска должна быть вида *.*",
                    "Ошибка ввода маски!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else {
                sf_lb_files.Cursor = Cursors.WaitCursor;
                this.Cursor = Cursors.WaitCursor;
                foreach (var file in Directory.GetFiles(sf_st_path.Text, sf_tb_masks.Text))
                    sf_lb_files.Items.Add(file.ToString());
                MessageBox.Show("Найдено файлов – " + sf_lb_files.Items.Count.ToString(), "Результат поиска", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                sf_lb_files.Cursor = Cursors.Default;
            }
        }
        private void Sf_tb_masks_TextChanged(object sender, EventArgs e) { // изменение текста в поле для ввода маски
            if (sf_tb_masks.Text.Length > 0)
                sf_b_startSearch.Enabled = true;
            else
                sf_b_startSearch.Enabled = false;
        }
        private void Sf_b_openFolder_Click(object sender, EventArgs e) { // открытие диалога выбора папки для поиска файлов
            FolderBrowserDialog dir = new FolderBrowserDialog();
            dir.ShowNewFolderButton = false; // отмена возможности создания папки, т.к. производится только поиск
            if (dir.ShowDialog() == DialogResult.OK) {
                sf_st_path.Text = dir.SelectedPath;
                sf_tb_masks.Enabled = true;
                sf_tb_masks.Focus();
            }
            else {
                dir = null;
                sf_st_path.Text = "";
                sf_tb_masks.Text = "";
                if (sf_tb_masks.Enabled)
                    sf_tb_masks.Enabled = false;
            }
        }
        private void sf_b_openFolder_MouseHover(object sender, EventArgs e) { // подсказки к кнопкам
            toolTip1.SetToolTip(sf_b_openFolder, "Выбор каталога");
        }
        private void sf_b_startSearch_MouseHover(object sender, EventArgs e) {
            toolTip1.SetToolTip(sf_b_startSearch, "Начать поиск");
        }
        private void sf_tb_masks_MouseHover(object sender, EventArgs e) { // подсказка к полю
            toolTip1.SetToolTip(sf_tb_masks, "Маска поиска, например: *.txt");
        }
    }
}