﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu {
    public partial class Form1 : Form {
        MenuStrip menu_;
        ToolStripMenuItem item_;
        public Form1() {
            InitializeComponent();
            menu_ = new MenuStrip();
        }
        private void button1_Click(object sender, EventArgs e) {
            item_ = (ToolStripMenuItem)menu_.Items.Add(TopLevelMenu.Text);
            this.MainMenuStrip = menu_;
            this.Controls.Add(menu_);
        }
        private void button2_Click(object sender, EventArgs e) {
            item_.DropDownItems.Add(SubItem.Text);
        }
    }
}

/*Задание
▪ Создайте Windows Forms приложение
▪ Добавьте на него текстовое поле с именем TopLevelMenu
▪ Добавьте текстовое поле с именем SubItem
▪ Добавьте кнопку «Добавить пункт меню»
▪ Добавьте кнопку «Добавить подменю»
▪ При нажатии на кнопку «Добавить пункт меню» должен добавляться пункт меню верхнего уровня, с именем указанным в поле TopLevelMenu
▪ При нажатии на кнопку «Добавить подменю» в текущее меню должен добавляться подпункт меню с именем указанным в поле SubItem*/