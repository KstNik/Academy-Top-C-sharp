﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Logo {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void Form1_Paint(object sender, PaintEventArgs e) { // создание нового Bitmap для хранения логотипа
            Bitmap logo = new Bitmap(57, 57);
            using (Graphics g = Graphics.FromImage(logo)) { // создание объекта Graphics для рисования на Bitmap
                SolidBrush brush = new SolidBrush(Color.Red); // цвет заливки
                Font font = new Font("Arial", 12, FontStyle.Bold); // шрифт
                Pen pen = new Pen(Color.Black, 3); // объект Pen для рисования рамки
                g.DrawString("Red", font, brush, new Point(10, 8)); // текст
                g.DrawString("Cube", font, brush, new Point(5, 27)); // …
                g.DrawRectangle(pen, 0, 0, 55, 55); // рамка
                g.Dispose();
            }
            pictureBox1.Image = logo; // отображение логотипа на форме
        }
    }
}

/*Задание 6. Используя GDI+, разработайте логотип вымышленной компании. Данный логотип будет 
динамически загружаться в приложение. Текст компании должен иметь окантовку.*/