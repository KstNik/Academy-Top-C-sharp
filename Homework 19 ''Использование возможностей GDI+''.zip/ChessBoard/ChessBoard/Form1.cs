﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessBoard {
    public partial class Form1 : Form {
        private const int CELL_SIZE = 50;
        private bool isWhiteCell = true;
        private Point selectedCell = new Point(-1, -1);
        public Form1() {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink; // запрет изменения размера
            this.MaximizeBox = false; // запрет развёртывания на весь экран
            this.Paint += ChessForm_Paint;
        }
        private void ChessForm_Paint(object sender, PaintEventArgs e) {
            Graphics g = e.Graphics;
            DrawChessBoard(g);
            g.Dispose();
        }
        private void DrawChessBoard(Graphics g) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    Brush brush = isWhiteCell ? Brushes.White : Brushes.Black;
                    g.FillRectangle(brush, j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    isWhiteCell = !isWhiteCell;
                }
                isWhiteCell = !isWhiteCell;
            }
            try {
                Bitmap im = new Bitmap(AppDomain.CurrentDomain.BaseDirectory + @"\Chessmen.png");
                g.DrawImage(im, 0, 0, 300, 100);
                im.Dispose();
            }
            catch { };
        }
        private void ChessForm_MouseClick(object sender, MouseEventArgs e) {
            selectedCell = new Point(e.X / CELL_SIZE, e.Y / CELL_SIZE);
            if (e.Button == MouseButtons.Right) {
                ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
                if ((selectedCell.X <= 5) && (selectedCell.Y <= 1)) {
                    switch (selectedCell.X) {
                        case 0:
                            contextMenuStrip.Items.Add("Король");
                            break;
                        case 1:
                            contextMenuStrip.Items.Add("Ферзь");
                            break;
                        case 2:
                            contextMenuStrip.Items.Add("Слон");
                            break;
                        case 3:
                            contextMenuStrip.Items.Add("Конь");
                            break;
                        case 4:
                            contextMenuStrip.Items.Add("Ладья");
                            break;
                        case 5:
                            contextMenuStrip.Items.Add("Пешка");
                            break;
                    }
                }
                else
                    contextMenuStrip.Items.Add("Свободная клетка");
                contextMenuStrip.Show(this, e.Location);
            }
        }
    }
}

/*Задание 1. Создайте приложение, которое будет рисовать шахматную доску и шахматные фигуры на клиентской области 
формы. Для каждой фигуры должно отображаться контекстное меню.*/