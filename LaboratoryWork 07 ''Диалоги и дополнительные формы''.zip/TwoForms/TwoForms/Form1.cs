﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TwoForms {
    public partial class MainForm : Form {
        private AdditionalForm additionalForm;
        public MainForm() {
            InitializeComponent();
            additionalForm = new AdditionalForm();
            additionalForm.Show();
        }
        private void textBoxMain_TextChanged(object sender, EventArgs e) {
            string text = textBoxMain.Text;
            additionalForm.UpdateBinaryText(ConvertToBinary(text));
        }
        private string ConvertToBinary(string text) {
            string binaryText = "";
            foreach (char c in text)
                binaryText += Convert.ToString(c, 2).PadLeft(8, '0') + " ";
            return binaryText.Trim();
        }
        private void buttonLoad(object sender, EventArgs e) {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK) {
                string filePath = openFileDialog.FileName;
                string fileText = File.ReadAllText(filePath);
                textBoxMain.Text = fileText;
            }
        }
        private void buttonSave(object sender, EventArgs e) {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK) {
                string filePath = saveFileDialog.FileName;
                File.WriteAllText(filePath, textBoxMain.Text);
            }
        }
    }
}

/*Задание
▪ Создайте Windows Forms приложение
▪ Добавьте на форму текстовое поле
▪ Добавьте дополнительную форму
▪ Добавьте кнопку Load
▪ Добавьте обработчик нажатия кнопки
▪ Добавьте кнопку Save
▪ Добавьте обработчик нажатия кнопки
▪ При загрузке приложения должны отображаться сразу 2 формы, – основная, и дополнительная
▪ При наборе текста в основной форме, в дополнительной форме, синхронно, должна отображаться информация в двоичном виде
▪ При нажатии на кнопку Load должен отображаться OpenFileDialog, и при открытии файла - информация из файла должна подгружаться в текстовое поле
▪ При нажатии на кнопку Save должен отображаться SaveFileDialog, с помощью которого нужно сохранить данные в соответствующий файл*/