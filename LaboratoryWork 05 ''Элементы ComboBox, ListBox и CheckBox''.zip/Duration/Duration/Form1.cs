﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Duration {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e) {
            for (int i = 0; i < progressBar1.Maximum; i++) {
                Thread.Sleep(10);
                progressBar1.PerformStep();
            }
            MessageBox.Show("Выполнение завершено!");
            Close();
        }
    }
}

/*Задание 2
Создайте новое приложение и поместите на форму компоненты PogressBar и кнопку. 
На событие click запустите цикл, который выполняется от 0 до 100. Чтобы цикл 
работал не очень быстро, добавьте в него строку с вызовом статичного метода 
sleep() класса Thread, которая создаст задержку на переданное в качестве 
параметра значение в миллисекундах.*/