﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, EventArgs e) {
            string surname = txtSurname.Text;
            string salary = txtSalary.Text;
            string position = cbPosition.Text;
            string city = cbCity.Text;
            string street = cbStreet.Text;
            string house = txtHouse.Text;
            if (string.IsNullOrEmpty(surname) || string.IsNullOrEmpty(salary) || string.IsNullOrEmpty(position) 
                    || string.IsNullOrEmpty(city) || string.IsNullOrEmpty(street) || string.IsNullOrEmpty(house)) {
                MessageBox.Show("Please fill in all fields", "Error");
                return;
            }
            decimal salaryValue;
            if (!decimal.TryParse(salary, out salaryValue)) {
                MessageBox.Show("Salary must be a valid number", "Error");
                return;
            }
            string employeeInfo = $"{surname}, {salary}, {position}, {city}, {street}, {house}";
            using (StreamWriter sw = File.AppendText("employees.txt")) {
                sw.WriteLine(employeeInfo);
            }
            lstEmployees.Items.Add(employeeInfo);
            txtSurname.Text = "";
            txtSalary.Text = "";
            cbPosition.SelectedIndex = -1;
            cbCity.SelectedIndex = -1;
            cbStreet.SelectedIndex = -1;
            txtHouse.Text = "";
        }
        private void btnAddPosition_Click(object sender, EventArgs e) {
            string newPosition = cbPosition.Text;
            if (!cbPosition.Items.Contains(newPosition)) {
                cbPosition.Items.Add(newPosition);
                cbPosition.Text = newPosition;
            }
        }
        private void btnAddCity_Click(object sender, EventArgs e) {
            string newCity = cbCity.Text;
            if (!cbCity.Items.Contains(newCity)) {
                cbCity.Items.Add(newCity);
                cbCity.Text = newCity;
            }
        }
        private void btnAddStreet_Click(object sender, EventArgs e) {
            string newStreet = cbStreet.Text;
            if (!cbStreet.Items.Contains(newStreet)) {
                cbStreet.Items.Add(newStreet);
                cbStreet.Text = newStreet;
            }
        }
    }
}

/*Задание 1
Программа должна иметь возможность ввода информации о работнике (фамилия, зарплата, 
должность, город, улица, дом) и записывать введённые данные в текстовый файл. 
Список работников выводить в элемент ListBox.
Для ускорения ввода полей «должность», «город», «улица» использовать элемент ComboBox. 
При отсутствии требуемого значения в списке окна ComboBox предусмотреть возможность 
ввода нового значения. Добавить обработку ошибок ввода (пустая строка и недопустимый 
числовой формат при вводе зарплаты).
*/