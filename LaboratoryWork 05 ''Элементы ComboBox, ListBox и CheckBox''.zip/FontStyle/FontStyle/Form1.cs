﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FontStyle {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) {
            if (checkBox1.Checked)
                label1.Font = new System.Drawing.Font(label1.Font, System.Drawing.FontStyle.Bold);
            else
                label1.Font = new System.Drawing.Font(label1.Font, System.Drawing.FontStyle.Regular);

        }
    }
}

/*Задание 3
Кнопка CheckBox (Флажок) также находится на панели элементов управления Toolbox. 
Флажок может быть либо установлен (содержит «галочку»), либо сброшен (пустой).
Напишите программу, которая управляет стилем шрифта текста, выведенного на метку Label. 
Управлять стилем будем посредством флажка CheckBox.
*/