﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Tabs {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            var tabPage3 = new TabPage(); // создание третьей вкладки
            tabPage3.UseVisualStyleBackColor = true;
            // добавление третьей вкладки в существующий набор вкладок
            this.tabControl1.Controls.Add(tabPage3);
            // добавление переключателей 5 и 6 на третью вкладку
            tabPage3.Controls.Add(this.radioButton5);
            tabPage3.Controls.Add(this.radioButton6);
            // их расположение
            this.radioButton5.Location = new Point(20, 15);
            this.radioButton6.Location = new Point(20, 58);
            this.Text = "Какая улыбка Вам ближе";
            tabControl1.TabPages[0].Text = "Текст";
            tabControl1.TabPages[1].Text = "Цвет";
            tabControl1.TabPages[2].Text = "Размер";
            radioButton1.Text =  "Восхищенная, сочувственная, \nскромно-смущенная";
            radioButton2.Text = "Нежная улыбка, ехидная, бесстыжая, \nподленькая, " +
                "снисходительная";
            radioButton3.Text = "Красный";
            radioButton4.Text = "Синий";
            radioButton5.Text = "11 пунктов";
            radioButton6.Text = "13 пунктов";
            label1.Text = radioButton1.Text;
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e) {
            label1.Text = radioButton1.Text;
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e) {
            label1.Text = radioButton2.Text;
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e) {
            label1.ForeColor = Color.Red;
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e) {
            label1.ForeColor = Color.Blue;
        }
        private void radioButton5_CheckedChanged(object sender, EventArgs e) {
            label1.Font = new Font(label1.Font.Name, 11);
        }
        private void radioButton6_CheckedChanged(object sender, EventArgs e) {
            label1.Font = new Font(label1.Font.Name, 13);
        }
    }
}
/*Задание 4
Вкладки программируют для организации управления и оптимального использования экранного 
пространства. Выразительным примером применения вкладок является диалоговое окно Свойства 
обозревателя Internet Explorer. То есть, если требуется отобразить большое количество 
управляемой информации, весьма уместно обратить внимание на вкладки TabControl.
Поставим задачу написать программу, позволяющую выбрать текст из двух вариантов, задать 
цвет и размер шрифта этого текста на трех вкладках TabControl с использованием переключателей 
RadioButton. Фрагмент работы программы приведён на рисунке.
Программируя поставленную задачу, перетащим в форму мышью элемент управления TabControl. 
Как можно видеть, по умолчанию предусмотрены две вкладки, а по условию задачи нам нужны три. 
Добавьте третью вкладку можно в конструкторе формы, а можно и программно. Для добавления 
через конструктор в свойствах (окно Properties) элемента управления TabControl выбираем 
свойство TabPages и в результате попадаем в диалоговое окно TabPage Collection Edit, где 
добавляем (кнопка Add) третью вкладку (первые две присутствуют по умолчанию). Эти вкладки 
нумеруются от нуля. т. с. третья вкладка определяется как TabPages(2). Название каждой 
вкладки будем указывать в программном коде.
Дальнейшие установки очевидны и не требуют дополнительных комментариев. Заметим, что каждая 
пара переключателей, расположенных на каком-либо элементе управления (в данном случае на 
различных вкладках), «отрицают» друг друга, т. с. если пользователь выбрал один переключатель, 
то другой переходит в противоположное состояние. Отслеживать изменения состояния переключателей 
удобно с помощью обработки событий переключателей CheckChanged. Чтобы получить пустой 
обработчик этого события в конструкторе формы, следует двойным щелчком щёлкнуть на 
соответствующем переключателе и таким образом запрограммировать изменения состояния 
переключателей.*/